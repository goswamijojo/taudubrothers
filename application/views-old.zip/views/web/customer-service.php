
<div class="page-title-area">
<div class="d-table">
<div class="d-table-cell">
<div class="container">
<div class="title-content">
<h2>Customer Service</h2>
<ul>
<li>
<a href="index.php">Home</a>
</li>
<li>
<span>Customer Service</span>
</li>
</ul>
</div>
</div>
</div>
</div>
<div class="title-img">
<img src="assets/images/page-title1.jpg" alt="About">
<img src="assets/images/shape16.png" alt="Shape">
<img src="assets/images/shape17.png" alt="Shape">
<img src="assets/images/shape18.png" alt="Shape">
</div>
</div>


<div class="common-faq-area ptb-100">
<div class="container">
<div class="faq-item">
<ul class="accordion">
<li>
<h3 class="faq-head">Shipping Times and Costs</h3>
<div class="faq-content">
<ul class="inner-list">
<li>1. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy</li>
<li>2. Eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua</li>
<li>3. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren</li>
<li>4. No sea takimata sanctus est Lorem ipsum dolor sit amet</li>
<li>5. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor <a href="#">[...]</a></li>
</ul>
</div>
</li>
<li>
<h3 class="faq-head">Payment Methods</h3>
<div class="faq-content">
<ul class="inner-list">
<li>1. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy</li>
<li>2. Eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua</li>
<li>3. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren</li>
<li>4. No sea takimata sanctus est Lorem ipsum dolor sit amet</li>
<li>5. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor <a href="#">[...]</a></li>
</ul>
</div>
</li>
<li>
<h3 class="faq-head">Exchanges, Returns and Refunds</h3>
<div class="faq-content">
<ul class="inner-list">
<li>1. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy</li>
<li>2. Eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua</li>
<li>3. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren</li>
<li>4. No sea takimata sanctus est Lorem ipsum dolor sit amet</li>
<li>5. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor <a href="#">[...]</a></li>
</ul>
</div>
</li>
</ul>
</div>
</div>
</div>
<?php
include("footer.php");
?>