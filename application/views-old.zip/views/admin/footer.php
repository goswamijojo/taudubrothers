<!-- /.content-wrapper -->
  <footer class="main-footer">
   
  </footer>


  
    
    <!-- jQuery 3 -->
    <script src="<?php echo base_url();?>Admin_dashborad/assets/vendor_components/jquery-3.3.1/jquery-3.3.1.js"></script>
    
    <!-- fullscreen -->
    <script src="<?php echo base_url();?>Admin_dashborad/assets/vendor_components/screenfull/screenfull.js"></script>
    
    <!-- jQuery UI 1.11.4 -->
    <script src="<?php echo base_url();?>Admin_dashborad/assets/vendor_components/jquery-ui/jquery-ui.js"></script>
    
    <!-- popper -->
    <script src="<?php echo base_url();?>Admin_dashborad/assets/vendor_components/popper/dist/popper.min.js"></script>
    
    <!-- Bootstrap 4.0-->
    <script src="<?php echo base_url();?>Admin_dashborad/assets/vendor_components/bootstrap/dist/js/bootstrap.js"></script>  
    
    <!-- Slimscroll -->
    <script src="<?php echo base_url();?>Admin_dashborad/assets/vendor_components/jquery-slimscroll/jquery.slimscroll.js"></script>
    
    <!-- FastClick -->
    <script src="<?php echo base_url();?>Admin_dashborad/assets/vendor_components/fastclick/lib/fastclick.js"></script>  
    
    <!--amcharts charts -->
    <script src="<?php echo base_url();?>Admin_dashborad/www.amcharts.com/lib/3/amcharts.js"></script>
    <script src="<?php echo base_url();?>Admin_dashborad/www.amcharts.com/lib/3/serial.js"></script>
    <script src="<?php echo base_url();?>Admin_dashborad/www.amcharts.com/lib/3/amstock.js"></script>
    <script src="<?php echo base_url();?>Admin_dashborad/www.amcharts.com/lib/3/plugins/export/export.min.js"></script>
    <script src="<?php echo base_url();?>Admin_dashborad/www.amcharts.com/lib/3/themes/black.js"></script>
    <script src="<?php echo base_url();?>Admin_dashborad/www.amcharts.com/lib/3/gauge.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>Admin_dashborad/www.amcharts.com/lib/3/pie.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>Admin_dashborad/www.amcharts.com/lib/3/plugins/animate/animate.min.js" type="text/javascript"></script>
    
    <!-- webticker -->
    <script src="<?php echo base_url();?>Admin_dashborad/assets/vendor_components/Web-Ticker-master/jquery.webticker.min.js"></script>
    
    <!-- Sparkline -->
    <script src="<?php echo base_url();?>Admin_dashborad/assets/vendor_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
    
    <!-- Crypto Admin App -->
    <script src="<?php echo base_url();?>Admin_dashborad/js/template.js"></script>
    
    <!-- Crypto Admin dashboard demo (This is only for demo purposes) -->
    <script src="<?php echo base_url();?>Admin_dashborad/js/pages/dashboard3.js"></script>
    <script src="<?php echo base_url();?>Admin_dashborad/js/pages/dashboard3-chart.js"></script>
    
    <!-- Crypto Admin for demo purposes -->
    <script src="<?php echo base_url();?>Admin_dashborad/js/demo.js"></script>
    
</body>

<!-- Mirrored from crypto-admin-templates.multipurposethemes.com/sass/dark/index-3.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 06:06:19 GMT -->
</html>
