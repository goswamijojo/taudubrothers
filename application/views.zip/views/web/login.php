<div class="page-title-area">
   <div class="d-table">
      <div class="d-table-cell">
         <div class="container">
            <div class="title-content">
               <h2>Login/Signup</h2>
               <ul>
                  <li>
                     <a href="<?php echo base_url();?>">Home</a>
                  </li>
                  <li>
                     <span>Login/Signup</span>
                  </li>
               </ul>
            </div>
         </div>
      </div>
   </div>
   <div class="title-img">
      <img src="<?php echo base_url('web/assets');?>/images/page-title1.jpg" alt="About">
      <img src="<?php echo base_url('web/assets');?>/images/shape16.png" alt="Shape">
      <img src="<?php echo base_url('web/assets');?>/images/shape17.png" alt="Shape">
      <img src="<?php echo base_url('web/assets');?>/images/shape18.png" alt="Shape">
   </div>
</div>
<div class="user-area ptb-100">
   <div class="container">
      <div class="user-item">
         <form method="post" action="<?php echo base_url('login_check') ?>">
            <h2>Login/Signup</h2>
            <?php if(!empty($this->session->flashdata('success'))){?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              <strong>Success!</strong><?php echo $this->session->flashdata('success'); ?>
            </div>
            <?php } ?>
            
            <?php if(!empty($this->session->flashdata('error'))){?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              <strong>Error!</strong><?php echo $this->session->flashdata('error'); ?>
            </div>
            <?php } ?>
            <div class="form-group">
               <input type="number" class="form-control" name="mobile_no" placeholder="Mobile No" pattern="[6789][0-9]{9}" title="Please enter valid phone number">
               
            </div>
            
            <button type="submit" class="btn common-btn">
            Login
            <img src="<?php echo base_url('web/assets');?>/images/shape1.png" alt="Shape">
            <img src="<?php echo base_url('web/assets');?>/images/shape2.png" alt="Shape">
            </button>
            
            <!--<h4>Or</h4>-->
            <!--<ul>-->
            <!--   <li>-->
            <!--      <a href="#">-->
            <!--      <i class='bx bxl-facebook'></i>-->
            <!--      Login With Facebook-->
            <!--      </a>-->
            <!--   </li>-->
            <!--   <li>-->
            <!--      <a href="#">-->
            <!--      <i class='bx bxl-google'></i>-->
            <!--      Login With Google-->
            <!--      </a>-->
            <!--   </li>-->
            <!--</ul>-->
           <!--<h5>Didn't Have An Account? <a href="<?php echo base_url();?>register">Register</a></h5>-->
         </form>
      </div>
   </div>
</div>