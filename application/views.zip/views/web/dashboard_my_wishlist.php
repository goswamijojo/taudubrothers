
<div class="page-title-area">
    <div class="d-table">
        <div class="d-table-cell">
            <div class="container">
                <div class="title-content">
                    <h3>Shopping Wishlist</h3>
                    <ul>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            <span>Shopping Wishlist</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="title-img">
        <img src="assets/images/page-title2.jpg" alt="About">
       
    </div>
</div>
<section class="dashboard-overview">
    <div class="">
        <div class="container">
            <div class="row">
            <div class="col-lg-3 col-md-4">
                <div class="left-side-tabs">
                    <div class="dashboard-left-links">
                        <a href="dashboard_overview.php" class="user-item"><i
                                class="uil uil-apps"></i>Overview</a>
                        <a href="dashboard_my_orders.php" class="user-item"><i class="uil uil-box"></i>My Orders</a>
                         <a href="kyc-vendor.php" class="user-item"><i class="uil uil-wallet"></i>My KYC</a>
                         <a href="add_product.php" class="user-item"><i class="uil uil-wallet"></i>Add Product</a>
                        <a href="dashboard_my_wishlist.php" class="user-item active"><i class="uil uil-heart"></i>Shopping
                            Wishlist</a>
                        <a href="dashboard_my_addresses.php" class="user-item"><i class="uil uil-location-point"></i>My
                            Address</a>
                        <a href="sign_in.php" class="user-item"><i class="uil uil-exit"></i>Logout</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-9 col-md-8">
<div class="dashboard-right">
<div class="row">
<div class="col-md-12">
<div class="main-title-tab">
<h4><i class="uil uil-heart"></i>Shopping Wishlist</h4>
</div>
</div>
<div class="col-lg-12 col-md-12">
<div class="pdpt-bg">
<div class="wishlist-body-dtt">
<div class="cart-item">
<div class="cart-product-img">
<img src="assets/images/products/img-11.jpg" alt="">
<div class="offer-badge">4% OFF</div>
</div>
<div class="cart-text">
<h4>Product Title Here</h4>
<div class="cart-item-price">$15 <span>$18</span></div>
<button type="button" class="cart-close-btn"><i class="uil uil-trash-alt"></i></button>
</div>
</div>
<div class="cart-item">
<div class="cart-product-img">
<img src="assets/images/products/img-2.jpg" alt="">
<div class="offer-badge">1% OFF</div>
</div>
<div class="cart-text">
<h4>Product Title Here</h4>
<div class="cart-item-price">$9.9 <span>$10</span></div>
<button type="button" class="cart-close-btn"><i class="uil uil-trash-alt"></i></button>
</div>
</div>
<div class="cart-item">
<div class="cart-product-img">
<img src="assets/images/products/img-14.jpg" alt="">
</div>
<div class="cart-text">
<h4>Product Title Here</h4>
<div class="cart-item-price">$12</div>
<button type="button" class="cart-close-btn"><i class="uil uil-trash-alt"></i></button>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>




</section>
